A Pen created at CodePen.io. You can find this one at https://codepen.io/anon/pen/bvzZRp.

 Example of simple login form with SVG icon. In future i would like to add tabs functionality to swich from sign in to sign up and back.

Here we go! My first pen since i registered and since i decided to change my work from UI/UX Designer to Front-end developer! 